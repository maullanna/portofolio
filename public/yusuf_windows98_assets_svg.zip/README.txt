YUSUF WINDOWS 98 PORTFOLIO — SVG ASSETS

These SVG files preserve the exact visual appearance of the PNG crops
from the supplied mockup by embedding the original pixel image inside SVG.

They are suitable for use as <img src="..."> assets in React.
For true vector scalability, the icons would need to be redrawn as
native SVG paths rather than embedding raster pixels.
